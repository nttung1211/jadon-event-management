create definer = clark@localhost trigger TG_delete_event
	before delete
	on events
	for each row
BEGIN
	DELETE FROM event_likes WHERE event_id = OLD.id;
    DELETE FROM event_comments WHERE event_id = OLD.id;
    DELETE FROM event_images WHERE event_id = OLD.id;
END;

