create definer = clark@localhost trigger TG_delete_user
	before delete
	on users
	for each row
BEGIN
	DELETE FROM event_likes WHERE user_id = OLD.id;
    DELETE FROM event_comments WHERE user_id = OLD.id;
END;

